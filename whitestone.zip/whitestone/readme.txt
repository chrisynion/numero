Development Steps
1. Setup local WordPress copy using XAMPP
2. Used the Underscores theme as a starter theme
3. Renamed the Underscore theme to Whitestone
4. Build the Figma design into the theme
5. Added the needed styles, fonts and scripts
6. Ensure everything is mobile responsive
